"""Configuration module for maze settings."""

from custom_typing.maze import Coordinate
import sys


class Config:
    """Configuration class for maze parameters."""

    def __init__(self, config_file: str) -> None:
        """Initialize configuration from a file."""
        print("Reading config file...")

        self.width: int = 0
        self.height: int = 0
        self.entry: Coordinate = (0, 0)
        self.exit: Coordinate = (0, 0)
        self.perfect: bool = False
        self.output_file: str = ""
        self.seed: int | None = None

        try:
            self.parse_file(config_file)
            self.check_config()
            print("[OK] Config File readed succesfully")

        except Exception as e:
            print(f"Config File Error: {e}")
            sys.exit(1)

    def parse_file(self, config_file: str) -> None:
        """Parse the configuration file and extract values."""
        try:
            with open(config_file, "r") as file:
                for line in file:
                    if line.strip() and not line.startswith("#"):
                        key, value = line.strip().split("=")
                        self.line_processor(key, value)
        except FileNotFoundError:
            raise Exception(f"Configuration file '{config_file}' not found!")
        except PermissionError:
            raise Exception(f"Permission denied to read '{config_file}'!")
        except Exception as e:
            raise Exception(f"Error occurred reading configuration file: {e}")

    def check_config(self) -> None:
        """Validate the configuration values."""
        if not hasattr(self, 'width') or not self.width:
            raise Exception("Value WIDTH is needed!")
        if self.width > 100 or self.height > 100:
            raise Exception("Maximum width and height is 100")
        if self.width < 10 or self.height < 10:
            raise Exception("Minimum width and height is 10")
        if not hasattr(self, 'height') or not self.height:
            raise Exception("Value HEIGHT is needed!")
        if not hasattr(self, 'entry') or not isinstance(self.entry, tuple):
            raise Exception("Value ENTRY is needed and must be a valid \
                            coordinate pair!")
        if self.entry[0] < 1 or self.entry[0] > self.width or self.entry[1] < (
                1) or self.entry[1] > self.height:
            raise Exception("Value ENTRY must be within the maze dimensions!")
        if self.exit[0] < 1 or self.exit[0] > self.width or self.exit[1] < (
                1) or self.exit[1] > self.height:
            raise Exception("Value EXIT must be within the maze dimensions!")
        if not hasattr(self, 'exit') or not isinstance(self.exit, tuple):
            raise Exception("Value EXIT is needed and must be a valid \
                            coordinate pair!")
        if not hasattr(self, 'perfect'):
            raise Exception("Value PERFECT is needed!")
        if not hasattr(self, 'output_file') or not self.output_file:
            raise Exception("Value OUTPUT_FILE is needed!")

    def line_processor(self, key: str, value: str) -> None:
        """Process a single configuration line."""
        try:
            if key == "WIDTH":
                self.width = int(value)
            elif key == "HEIGHT":
                self.height = int(value)
            elif key == "ENTRY":
                x, y = value.split(",")
                self.entry = (int(x), int(y))
            elif key == "EXIT":
                x, y = value.split(",")
                self.exit = (int(x), int(y))
            elif key == "PERFECT":
                if value == "True":
                    self.perfect = True
                elif value == "False":
                    self.perfect = False
                else:
                    raise ValueError("Invalid boolean for PERFECT")
            elif key == "OUTPUT_FILE":
                self.output_file = value
            elif key == "SEED":
                self.seed = int(value)
            else:
                raise ValueError(f"Unknown configuration key: {key}")
        except Exception as e:
            raise Exception(f"Error processing key '{key}': {e}")

    @staticmethod
    def get_config_file() -> str:
        if len(sys.argv) != 2:
            print("Error: Invalid number of arguments!")
            print("Usage: python a_maze_ing.py <config_file.txt>")
            sys.exit(1)

        config_file_str = sys.argv[1]

        if not config_file_str.endswith('.txt'):
            print("Error: Configuration file must be a .txt file!")
            print("Usage: python a_maze_ing.py <config_file.txt>")
            sys.exit(1)

        return config_file_str
